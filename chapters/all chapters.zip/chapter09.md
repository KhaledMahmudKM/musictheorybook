# Chapter 9 — Harmony and Chord Progressions

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what harmony is.
- Understand functional harmony (tonic, subdominant, dominant).
- Identify cadences and their types.
- Use Roman numeral analysis for chords.
- Recognize common chord progressions.
- Understand the ii–V–I and I–V–vi–IV progressions.
- Understand the basics of the 12-bar blues.

---

## Introduction

If melody is what you sing, and rhythm is when you sing it, then **harmony is what supports it underneath**.

Harmony is created when chords are used in sequence, forming a sense of movement, tension, and resolution. Most songs you hear in Western music are built on repeating patterns of chords called **chord progressions**.

Understanding harmony allows you to:

- Predict how music will move.
- Understand why certain chords sound “right” together.
- Write your own songs.
- Analyze existing music.

---

## What Is Harmony?

**Harmony** is the combination of notes played at the same time and how these combinations move over time.

In practice, harmony usually refers to:

- Chords
- Chord progressions
- The relationships between chords

While a single chord has a sound, harmony comes from how chords connect to each other.

---

## Functional Harmony

In tonal music, chords are not random—they have **functions**. Most harmony revolves around three main functions:

### Tonic (T)
The **tonic** is the "home" chord. It feels stable and resolved.

- I (major) or i (minor)
- Example: C major in C major key

### Subdominant (S)
The **subdominant** creates movement away from home.

- IV or ii
- Example: F major in C major key

### Dominant (D)
The **dominant** creates tension that strongly wants to resolve back to tonic.

- V or vii°
- Example: G major or G7 in C major key

---

## The Harmonic Flow

Most traditional harmony follows this basic movement:

```
Tonic → Subdominant → Dominant → Tonic
```

Or more simply:

```
I → IV → V → I
```

This creates a complete musical “sentence”:

- I = Home
- IV = Departure
- V = Tension
- I = Return

---

## Cadences

A **cadence** is a chord progression that ends a phrase or section of music. It is like punctuation in language.

### Authentic Cadence (V → I)

```
V → I
```

- Strongest resolution
- Sounds finished and stable

Example:

```
G → C
```

---

### Half Cadence (ends on V)

```
... → V
```

- Feels unfinished
- Creates anticipation

---

### Plagal Cadence (IV → I)

```
IV → I
```

- Often called the “Amen cadence”
- Gentle resolution

Example:

```
F → C
```

---

### Deceptive Cadence (V → vi)

```
V → vi
```

- Expectation is broken
- Creates surprise

Example:

```
G → Am
```

---

## Roman Numeral Analysis

Roman numerals are used to describe chords relative to a key.

In **C major**:

| Degree | Chord | Roman Numeral |
|--------|-------|---------------|
| C | C major | I |
| D | D minor | ii |
| E | E minor | iii |
| F | F major | IV |
| G | G major | V |
| A | A minor | vi |
| B | B diminished | vii° |

### Rules:

- Uppercase = major chord
- Lowercase = minor chord
- ° = diminished chord

This system works in every key.

---

## Why Roman Numerals Matter

Roman numerals let us describe chord progressions without needing a specific key.

For example:

```
I – V – vi – IV
```

means the same progression in every key:

- In C major: C – G – Am – F
- In G major: G – D – Em – C
- In D major: D – A – Bm – G

---

## Common Chord Progressions

### I – IV – V – I

One of the most fundamental progressions.

Example in C major:

```
C → F → G → C
```

Used in classical, folk, and pop music.

---

### I – V – vi – IV

One of the most popular modern progressions.

Example in C major:

```
C → G → Am → F
```

Used in countless pop songs.

It is popular because it balances:

- Stability (I)
- Tension (V)
- Emotion (vi)
- Resolution (IV)

---

### vi – IV – I – V

A variation of the above progression.

Example:

```
Am → F → C → G
```

Often used in ballads and emotional songs.

---

## The ii–V–I Progression

This is one of the most important progressions in jazz and classical harmony.

In C major:

```
Dm → G → C
```

Roman numerals:

```
ii → V → I
```

Why it works:

- ii = preparation
- V = tension
- I = resolution

This creates a very smooth and logical harmonic motion.

---

## The 12-Bar Blues

The **12-bar blues** is a repeating chord structure commonly used in blues, rock, and jazz.

In C major, it follows this pattern:

```
| C  | C  | C  | C  |
| F  | F  | C  | C  |
| G  | F  | C  | C  |
```

Roman numerals:

```
| I | I | I | I |
| IV | IV | I | I |
| V | IV | I | I |
```

This structure is the foundation of countless songs.

---

## Chord Movement and Voice Leading

Good harmony is not only about which chords are used, but also how smoothly they connect.

**Voice leading** refers to how individual notes in chords move from one chord to the next.

Good voice leading:

- Minimizes large jumps
- Keeps common tones when possible
- Creates smooth melodic motion between chords

Example:

```
C → Am
C E G → A C E
```

Notice:
- C stays C
- E stays E
- G moves to A

This smooth connection makes progressions sound natural.

---

## Tension and Resolution

Harmony is often described in terms of tension and release:

- **Tonic** = rest
- **Dominant** = tension
- **Resolution** = return to tonic

This creates emotional movement in music.

Example:

```
G7 → C
```

The tension in G7 resolves naturally to C major.

---

## Practice Examples

### Example 1

What are the three main harmonic functions?

**Answer:**
- Tonic
- Subdominant
- Dominant

---

### Example 2

What is the Roman numeral for the dominant chord in C major?

**Answer:**

```
V
```

---

### Example 3

What is the chord progression I–V–vi–IV in C major?

**Answer:**

```
C → G → Am → F
```

---

### Example 4

What is a cadence?

**Answer:**

A chord progression that ends a musical phrase or section.

---

### Example 5

What progression defines the 12-bar blues structure in Roman numerals?

**Answer:**

```
I – I – I – I
IV – IV – I – I
V – IV – I – I
```

---

## Key Takeaways

- Harmony is the relationship between chords over time.
- Functional harmony is based on tonic, subdominant, and dominant roles.
- Cadences are chord endings that create punctuation in music.
- Roman numerals describe chords relative to a key.
- Common progressions include I–IV–V, I–V–vi–IV, and ii–V–I.
- The 12-bar blues is one of the most important repeating structures in music.
- Voice leading improves the smoothness of chord movement.
- Tension and resolution drive musical expression.

---

## Summary

Harmony gives music its structure and emotional direction. In this chapter, you learned how chords function within tonal music, how Roman numerals help generalize progressions across all keys, and how common patterns like I–V–vi–IV and ii–V–I form the foundation of much Western music. You also explored cadences, voice leading, and the 12-bar blues structure.

In the next chapter, you will learn how **melody** is constructed and how it interacts with harmony to create memorable musical ideas.