# Chapter 11 — Keys and Modulation

## Learning Objectives

By the end of this chapter, you should be able to:

- Define what a musical key is.
- Identify the tonic as the tonal center of a piece.
- Understand closely related keys.
- Use the Circle of Fifths to understand key relationships.
- Explain what modulation is.
- Recognize pivot chords.
- Understand borrowed chords (modal mixture basics).

---

## Introduction

Music is rarely just a random collection of notes and chords. Most music is organized around a **key**, which acts as a central “home base.”

However, many pieces do not stay in one key the entire time. They may shift temporarily or permanently to another key. This process is called **modulation**.

Understanding keys and modulation helps you follow the emotional and structural journey of a piece of music.

---

## What Is a Key?

A **key** is a system of pitches centered around a **tonic note**, which feels like “home.”

For example:

- C Major has C as its tonic.
- A Minor has A as its tonic.

A key defines:

- Which notes are used (scale)
- Which chords are most important
- Where musical tension resolves

---

## Tonic as the Center of Music

The **tonic** is the most stable and important note or chord in a key.

In C major:

- Tonic note: C
- Tonic chord: C major (I)

Most melodies and harmonies eventually return to the tonic to create a sense of resolution.

Example:

```
G → F → D → C
```

Even though the melody moves, it feels “complete” when it lands on C.

---

## Closely Related Keys

Some keys are more closely related than others because they share many of the same notes.

Closely related keys are usually:

- The **relative minor/major**
- The **dominant key (V)**
- The **subdominant key (IV)**

Example: C Major

| Relationship | Key |
|--------------|-----|
| Relative minor | A minor |
| Dominant | G major |
| Subdominant | F major |

These keys are easy to move between because they share most of their notes.

---

## The Circle of Fifths (Revisited)

The **Circle of Fifths** shows relationships between keys.

Moving clockwise:

- Adds sharps
- Moves to the dominant key

```
C → G → D → A → E → B → F♯
```

Moving counterclockwise:

- Adds flats
- Moves to the subdominant key

```
C → F → B♭ → E♭ → A♭ → D♭
```

The Circle of Fifths helps you:

- Identify key signatures
- Understand modulation paths
- Predict harmonic movement

---

## What Is Modulation?

**Modulation** is the process of changing from one key to another within a piece of music.

For example:

- A song starts in C major.
- Later it moves to G major.
- Then it returns to C major.

Modulation creates:

- Contrast
- Emotional development
- Structural interest

---

## Types of Modulation

### 1. Direct Modulation

A sudden, unprepared key change.

Example:

```
C major → E major (abrupt shift)
```

This is often used for dramatic effect.

---

### 2. Pivot-Chord Modulation

A smoother modulation using a **pivot chord** that belongs to both keys.

---

## Pivot Chords

A **pivot chord** is a chord that is shared between two keys.

It acts as a bridge during modulation.

Example:

From C major to G major:

In C major:
```
C  Dm  Em  F  G  Am  Bdim
```

In G major:
```
G  Am  Bm  C  D  Em  F♯dim
```

Shared chords include:

- C
- Am
- Em
- G

Example modulation:

```
C → Am → D → G
```

Here, **Am** can function in both keys, helping smooth the transition.

---

## How to Hear Modulation

You can often detect modulation by noticing:

- A new chord feels like “home”
- The tonic changes
- The leading tone shifts
- The final resolution lands somewhere unexpected

Example:

```
C → F → G → D → A
```

If A begins to feel like home, the music may have modulated to D major or A minor.

---

## Closely Related Modulations

The easiest modulations occur between closely related keys:

From C major:

- G major (dominant)
- F major (subdominant)
- A minor (relative minor)

These transitions sound natural because they share many common tones.

---

## Borrowed Chords (Modal Mixture)

Sometimes music borrows chords from the **parallel key** (same tonic, different mode).

Example:

C major borrowing from C minor:

- C minor has E♭, A♭, B♭

Borrowed chord example:

```
C major progression:
C → F → Fm → C
```

Here, **Fm** is borrowed from C minor.

Borrowed chords add:

- Color
- Emotional contrast
- Harmonic variety

---

## Secondary Dominants (Introduction)

A **secondary dominant** is a dominant chord that temporarily tonicizes another chord.

Example in C major:

```
D7 → G → C
```

- D7 is the dominant of G (V of V)
- It temporarily makes G feel like a tonic

This strengthens harmonic direction and makes progressions more dynamic.

---

## Modulation vs Tonicization

It is important to distinguish:

### Tonicization

- Temporary emphasis on another chord
- Short-lived
- Does not fully change key

### Modulation

- Full shift to a new tonic
- More permanent (within the piece)

---

## Practical Example of Modulation

Start in C major:

```
C → Am → Dm → G → C
```

Now pivot:

```
C → Am → D → G → C → D → G
```

At this point, G feels like the new home key.

We have modulated from C major to G major.

---

## Why Modulation Is Used

Composers use modulation to:

- Add emotional development
- Prevent repetition
- Create contrast between sections
- Build tension and release over time

Common in:

- Classical sonatas
- Pop song key changes (final chorus uplift)
- Jazz improvisation
- Film scores

---

## Practice Examples

### Example 1

What is a musical key?

**Answer:**
A system of notes centered around a tonic.

---

### Example 2

What is modulation?

**Answer:**
A change from one key to another within a piece of music.

---

### Example 3

What is a pivot chord?

**Answer:**
A chord shared by two keys that helps transition between them.

---

### Example 4

Name three closely related keys to C major.

**Answer:**
- G major
- F major
- A minor

---

### Example 5

What is the difference between modulation and tonicization?

**Answer:**
- Modulation = full key change
- Tonicization = temporary emphasis on another chord

---

## Key Takeaways

- A key defines the tonal center of a piece.
- The tonic is the “home” of the key.
- Closely related keys share many notes and are easier to transition between.
- Modulation is a change of key within a piece.
- Pivot chords smooth the transition between keys.
- Borrowed chords come from the parallel key.
- Secondary dominants briefly tonicize other chords.
- Modulation adds variety, contrast, and emotional development.

---

## Summary

Keys provide the structural foundation of tonal music, while modulation allows music to move between different tonal centers. In this chapter, you learned how keys are organized around a tonic, how closely related keys function, and how modulation can occur through direct shifts or smooth transitions using pivot chords. You also explored borrowed chords and secondary dominants, both of which expand harmonic possibilities.

In the next chapter, you will learn about **musical form**, which explains how entire pieces of music are structured over time.