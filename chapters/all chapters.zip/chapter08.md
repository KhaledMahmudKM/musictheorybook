# Chapter 8 — Seventh and Extended Chords

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what seventh chords are.
- Construct the most common seventh chords.
- Understand dominant harmony.
- Recognize extended chords.
- Read common seventh and extended chord symbols.
- Understand when these chords are commonly used.

---

## Introduction

In the previous chapter, you learned that most chords are built as **triads**, consisting of a root, third, and fifth.

Music often becomes richer by adding another note—a **seventh** above the root. This creates a **seventh chord**, one of the most frequently used chord types in Western music.

Additional notes beyond the seventh create **extended chords**, which are especially common in jazz, blues, soul, R&B, and modern pop music.

---

## Building Seventh Chords

A seventh chord is created by adding another third above the fifth of a triad.

For example, starting with the C Major triad:

```
C  E  G
```

Add another third:

```
C  E  G  B
```

The added note (B) is the **seventh** above C.

The chord now contains four notes:

- Root
- Third
- Fifth
- Seventh

---

## Types of Seventh Chords

Several types of seventh chords are commonly used.

The chord quality depends on both the triad and the type of seventh that is added.

---

## Major Seventh Chord

A **Major Seventh (Maj7)** chord consists of:

- Root
- Major Third
- Perfect Fifth
- Major Seventh

Formula:

```
Root + Major 3rd + Perfect 5th + Major 7th
```

Example:

```
C  E  G  B
```

Chord symbol:

```
Cmaj7
```

Major seventh chords have a smooth, warm, and sophisticated sound.

They are frequently heard in:

- Jazz
- Ballads
- Film music
- Contemporary pop

---

## Dominant Seventh Chord

The **Dominant Seventh (7)** chord is one of the most important chords in tonal harmony.

Formula:

```
Root + Major 3rd + Perfect 5th + Minor 7th
```

Example:

```
G  B  D  F
```

Chord symbol:

```
G7
```

Unlike the major seventh chord, the dominant seventh naturally creates tension that strongly resolves to the tonic.

For example:

```
G7 → C
```

This progression is one of the most common in Western music.

---

## Minor Seventh Chord

A **Minor Seventh (m7)** chord consists of:

- Root
- Minor Third
- Perfect Fifth
- Minor Seventh

Formula:

```
Root + Minor 3rd + Perfect 5th + Minor 7th
```

Example:

```
A  C  E  G
```

Chord symbol:

```
Am7
```

Minor seventh chords produce a mellow, relaxed sound and are common in jazz, blues, and pop.

---

## Half-Diminished Seventh Chord

A **Half-Diminished Seventh** chord consists of:

- Root
- Minor Third
- Diminished Fifth
- Minor Seventh

Formula:

```
Root + Minor 3rd + Diminished 5th + Minor 7th
```

Example:

```
B  D  F  A
```

Chord symbol:

```
Bm7♭5
```

or

```
Bø7
```

This chord frequently appears as the seventh chord built on the seventh degree of a major scale.

---

## Fully Diminished Seventh Chord

A **Fully Diminished Seventh** chord consists of:

- Root
- Minor Third
- Diminished Fifth
- Diminished Seventh

Formula:

```
Root + Minor 3rd + Diminished 5th + Diminished 7th
```

Example:

```
B  D  F  A♭
```

Chord symbol:

```
Bdim7
```

or

```
B°7
```

Fully diminished chords create a strong sense of tension and are often used to connect one chord to another.

---

## Comparing Seventh Chords

| Chord Type | Formula |
|------------|---------|
| Major Seventh | Root – Major 3rd – Perfect 5th – Major 7th |
| Dominant Seventh | Root – Major 3rd – Perfect 5th – Minor 7th |
| Minor Seventh | Root – Minor 3rd – Perfect 5th – Minor 7th |
| Half-Diminished Seventh | Root – Minor 3rd – Diminished 5th – Minor 7th |
| Fully Diminished Seventh | Root – Minor 3rd – Diminished 5th – Diminished 7th |

---

## Diatonic Seventh Chords in a Major Key

Each degree of a major scale naturally produces a seventh chord.

Using the C Major scale:

```
C  D  E  F  G  A  B
```

The resulting seventh chords are:

| Scale Degree | Chord |
|--------------|-------|
| I | Cmaj7 |
| ii | Dm7 |
| iii | Em7 |
| IV | Fmaj7 |
| V | G7 |
| vi | Am7 |
| vii° | Bm7♭5 |

Notice that the dominant seventh naturally appears on the fifth degree of the major scale.

---

## Why Is the Dominant Seventh So Important?

The dominant seventh contains notes that naturally lead toward the tonic.

For example:

```
G  B  D  F
```

resolves naturally to:

```
C  E  G
```

The interval between **B** and **F** (a tritone) creates tension that seeks resolution.

Because of this, the progression:

```
V7 → I
```

is one of the strongest and most recognizable movements in tonal music.

---

## Extended Chords

Instead of stopping at the seventh, additional thirds can be stacked to create **extended chords**.

These additional notes are:

```
9th
11th
13th
```

Although the numbers are larger than seven, they correspond to notes already found within the scale, one octave higher.

---

## Ninth Chords

A **ninth chord** adds the ninth degree above the root.

Example:

```
C  E  G  B♭  D
```

Chord symbol:

```
C9
```

Ninth chords sound fuller than ordinary seventh chords and are widely used in jazz, blues, gospel, and soul music.

---

## Eleventh Chords

An **eleventh chord** adds the eleventh above the root.

Example:

```
C  E  G  B♭  D  F
```

Chord symbol:

```
C11
```

Because the eleventh may clash with the third, musicians often omit certain notes depending on the musical context.

---

## Thirteenth Chords

A **thirteenth chord** adds the thirteenth above the root.

Example:

```
C  E  G  B♭  D  F  A
```

Chord symbol:

```
C13
```

In practice, performers usually omit some notes so that the chord remains playable.

---

## Added-Note Chords

Not every chord with an extra note is an extended chord.

An **added-note chord** includes an additional note without adding a seventh.

For example:

```
C  E  G  D
```

Chord symbol:

```
Cadd9
```

Unlike a C9 chord, a Cadd9 chord does **not** include the minor seventh (B♭).

Added-note chords are common in pop, folk, and contemporary worship music.

---

## Slash Chords

A **slash chord** indicates a specific bass note.

Example:

```
C/E
```

This means:

- Play a C Major chord.
- Use E as the lowest note.

Slash chords are commonly used to create smoother bass lines and chord transitions.

---

## Common Chord Symbols

| Symbol | Meaning |
|--------|---------|
| Cmaj7 | Major Seventh |
| C7 | Dominant Seventh |
| Cm7 | Minor Seventh |
| Cm7♭5 | Half-Diminished Seventh |
| Cdim7 | Fully Diminished Seventh |
| C9 | Ninth Chord |
| C11 | Eleventh Chord |
| C13 | Thirteenth Chord |
| Cadd9 | Added Ninth |
| C/E | Slash Chord |

---

## Practice Examples

### Example 1

Construct a C Major Seventh chord.

**Answer:**

```
C  E  G  B
```

---

### Example 2

Construct a G Dominant Seventh chord.

**Answer:**

```
G  B  D  F
```

---

### Example 3

Construct an A Minor Seventh chord.

**Answer:**

```
A  C  E  G
```

---

### Example 4

What is the seventh chord built on the fifth degree of the C Major scale?

**Answer:**

```
G7
```

---

### Example 5

What is the difference between C9 and Cadd9?

**Answer:**

- **C9** includes a dominant seventh (B♭) and a ninth (D).
- **Cadd9** includes the ninth (D) but does not include the seventh.

---

## Key Takeaways

- Seventh chords are formed by adding another third above a triad.
- The five most common seventh chords are major seventh, dominant seventh, minor seventh, half-diminished seventh, and fully diminished seventh.
- The dominant seventh chord plays a central role in tonal harmony.
- Extended chords continue stacking thirds beyond the seventh.
- Ninth, eleventh, and thirteenth chords add richness and color to harmony.
- Added-note chords are different from extended chords because they do not require a seventh.
- Slash chords specify the bass note while preserving the chord quality.

---

## Summary

Seventh chords expand the harmonic possibilities of basic triads by adding another layer of tension and color. In this chapter, you learned how the five common seventh chords are constructed, why the dominant seventh is so important in tonal harmony, and how extended chords such as ninth, eleventh, and thirteenth chords create richer harmonic textures. You also explored added-note and slash chords, both of which are widely used in modern music.

In the next chapter, you will learn how chords work together to create **harmony and chord progressions**, the foundation of most songs and instrumental music.