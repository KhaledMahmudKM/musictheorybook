# Chapter 1 — What Is Music Theory?

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what music theory is.
- Understand the difference between sound and music.
- Describe the concepts of pitch, frequency, and loudness.
- Name the seven musical note letters.
- Explain what an octave is.
- Understand enharmonic equivalents.

---

# What Is Music Theory?

Music theory is the study of how music works. It provides a language for describing and understanding melodies, rhythms, chords, scales, harmony, and musical structure.

Just as grammar helps us understand and communicate in a spoken language, music theory helps musicians understand and communicate musical ideas.

Learning music theory does **not** automatically make someone a great musician. Likewise, many talented musicians have little formal knowledge of music theory. Instead, music theory helps explain *why* certain musical ideas sound pleasing, tense, or expressive, making it easier to learn, perform, compose, and analyze music.

---

# Why Learn Music Theory?

Music theory provides many practical benefits, including:

- Reading and writing sheet music.
- Learning songs more quickly.
- Understanding scales and chords.
- Communicating with other musicians.
- Improvising with greater confidence.
- Composing original music.
- Analyzing existing music.

Whether you play piano, guitar, violin, drums, or produce music electronically, a basic understanding of music theory makes learning easier.

---

# Sound vs. Music

Everything we hear begins as **sound**, which is created when an object vibrates.

Examples include:

- A guitar string vibrating.
- Air passing through a flute.
- A drumhead vibrating after being struck.
- Vocal cords vibrating while singing.

These vibrations travel through the air as sound waves until they reach our ears.

Not every sound is considered music.

Examples of sounds:

- Traffic
- Rain
- A dog barking
- Wind
- A piano note

Music is an organized arrangement of sounds that usually includes:

- Pitch
- Rhythm
- Harmony
- Melody
- Dynamics

Although some modern musical styles intentionally blur the distinction between sound and music, most music is built from organized patterns rather than random noise.

---

# Pitch

**Pitch** describes how high or low a sound appears to our ears.

Higher pitch:
- Whistle
- Birdsong
- Small bells

Lower pitch:
- Bass guitar
- Tuba
- Thunder

Pitch is determined by the frequency of vibration.

Generally:

- Faster vibration → Higher pitch
- Slower vibration → Lower pitch

---

# Frequency

**Frequency** is the number of vibrations per second.

It is measured in **Hertz (Hz)**.

Examples:

| Frequency | Approximate Note |
|-----------|------------------|
| 110 Hz | A2 |
| 220 Hz | A3 |
| 440 Hz | A4 (Concert A) |
| 880 Hz | A5 |

Notice that each time the frequency doubles, we hear the note as the same musical note at a higher pitch (an octave higher).

For example:

- 220 Hz → A3
- 440 Hz → A4
- 880 Hz → A5

Although the frequencies are different, they all sound like versions of the note **A**.

---

# Loudness

While **pitch** describes how high or low a sound is, **loudness** describes how strong the sound is.

Examples:

- Whisper
- Conversation
- Orchestra
- Rock concert

Loudness mainly depends on the size (amplitude) of the sound wave.

In music notation, loudness is indicated using **dynamics**, such as:

| Symbol | Meaning |
|--------|---------|
| pp | Very soft |
| p | Soft |
| mp | Moderately soft |
| mf | Moderately loud |
| f | Loud |
| ff | Very loud |

You will learn more about dynamics in a later chapter.

---

# The Musical Alphabet

Unlike the English alphabet, music uses only **seven letter names**:

> A B C D E F G

After G, the sequence repeats:

> A B C D E F G A B C ...

These seven letters represent all musical notes.

Unlike ordinary numbering systems, musical notes repeat in cycles called **octaves**.

---

# Octaves

An **octave** is the interval between one note and the next note with the same letter name.

For example:

- C to C
- D to D
- F to F

On a piano keyboard, each octave contains:

- Seven white-note letter names
- Five black keys
- Twelve distinct pitches in total

Although the notes repeat their names, each higher octave has approximately **double the frequency** of the previous one.

For example:

| Note | Frequency |
|------|-----------|
| A3 | 220 Hz |
| A4 | 440 Hz |
| A5 | 880 Hz |

This repeating pattern is one of the fundamental ideas in music.

---

# Accidentals

Sometimes a note is raised or lowered by one semitone (half step).

These changes are indicated by **accidentals**.

| Symbol | Name | Effect |
|--------|------|--------|
| ♯ | Sharp | Raise the note by one semitone |
| ♭ | Flat | Lower the note by one semitone |
| ♮ | Natural | Return to the original note |

Examples:

- C♯ is one semitone higher than C.
- B♭ is one semitone lower than B.
- F♮ cancels a previous sharp or flat.

---

# Enharmonic Notes

Some notes have two different names but produce the same pitch.

These are called **enharmonic equivalents**.

Examples:

| Note | Same Pitch As |
|------|---------------|
| C♯ | D♭ |
| D♯ | E♭ |
| F♯ | G♭ |
| G♯ | A♭ |
| A♯ | B♭ |

Although they sound identical on most modern instruments, they may be written differently depending on the musical key or context.

For example:

- C♯ Major uses sharps.
- D♭ Major uses flats.

The choice of name helps musicians read and understand the music more easily.

---

# Key Takeaways

- Music theory explains how music is organized and structured.
- Sound is produced by vibrations.
- Pitch describes how high or low a sound is.
- Frequency is measured in Hertz (Hz).
- Loudness depends on the amplitude of the sound wave.
- Music uses seven note letters: A, B, C, D, E, F, and G.
- An octave spans from one note to the next note with the same letter name.
- Accidentals raise or lower notes by one semitone.
- Some notes have different names but the same pitch; these are called enharmonic equivalents.

---

# Summary

Music begins with sound, but music theory helps us understand how sounds are organized into meaningful musical ideas. In this chapter, you learned about pitch, frequency, loudness, the musical alphabet, octaves, accidentals, and enharmonic notes. These concepts form the foundation for everything that follows in music theory.

In the next chapter, you will learn how notes are separated by intervals and how these intervals form the building blocks of scales, chords, and melodies.