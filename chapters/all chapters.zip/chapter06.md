# Chapter 6 — Minor Scales and Musical Modes

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain the characteristics of minor scales.
- Construct natural, harmonic, and melodic minor scales.
- Distinguish between relative and parallel keys.
- Understand the purpose of musical modes.
- Recognize the seven traditional modes.
- Identify common uses of minor scales and modes.

---

## Introduction

While major scales often sound bright and uplifting, **minor scales** are commonly associated with darker, more emotional, or more mysterious moods. Both major and minor keys are fundamental to Western music, and many pieces move between them.

In addition to major and minor scales, musicians also use **modes**—alternative scale patterns that create distinctive musical colors.

---

## The Natural Minor Scale

The **natural minor scale** is the simplest and most common type of minor scale.

Its interval pattern is:

```
W – H – W – W – H – W – W
```

where:

- **W** = Whole step
- **H** = Half step

For example, the A Natural Minor scale is:

```
A  B  C  D  E  F  G  A
```

Notice that it contains **no sharps or flats**, just like the C Major scale.

---

## Comparing Major and Minor Scales

Compare the C Major and A Natural Minor scales:

### C Major

```
C  D  E  F  G  A  B  C
```

### A Natural Minor

```
A  B  C  D  E  F  G  A
```

Although they use exactly the same notes, they have different tonal centers.

- C Major feels resolved on **C**.
- A Minor feels resolved on **A**.

This difference creates a completely different musical character.

---

## Relative Minor

Every major key has a **relative minor**.

A relative minor:

- Uses the same key signature.
- Contains the same notes.
- Begins on the sixth degree of the major scale.

Examples:

| Major Key | Relative Minor |
|-----------|----------------|
| C Major | A Minor |
| G Major | E Minor |
| D Major | B Minor |
| F Major | D Minor |
| B♭ Major | G Minor |

A quick way to find the relative minor is to count down three semitones (or up six scale degrees) from the major tonic.

Example:

```
C → B → B♭ → A
```

Therefore:

```
C Major ↔ A Minor
```

---

## Parallel Minor

A **parallel minor** shares the **same tonic** as its major key but uses a different set of notes.

Examples:

| Major | Parallel Minor |
|--------|----------------|
| C Major | C Minor |
| G Major | G Minor |
| D Major | D Minor |

Compare:

### C Major

```
C  D  E  F  G  A  B
```

### C Minor (Natural)

```
C  D  E♭  F  G  A♭  B♭
```

Unlike relative keys, parallel keys do **not** share the same key signature.

---

## The Harmonic Minor Scale

The natural minor scale sometimes lacks a strong pull back to the tonic because its seventh degree is a whole step below the tonic.

To strengthen this resolution, the seventh degree is raised by one semitone.

The interval pattern becomes:

```
W – H – W – W – H – W+H – H
```

where **W+H** represents an interval of three semitones (an augmented second).

Example:

### A Harmonic Minor

```
A  B  C  D  E  F  G♯  A
```

Compared with A Natural Minor:

```
A  B  C  D  E  F  G  A
```

only the seventh note changes.

The raised seventh creates a strong tendency for:

```
G♯ → A
```

This makes harmonic minor especially useful for harmony and chord progressions.

---

## The Melodic Minor Scale

The **melodic minor scale** modifies two notes when ascending.

Ascending:

- Raise the sixth degree.
- Raise the seventh degree.

Descending:

- Return to the natural minor form.

Example:

### Ascending

```
A  B  C  D  E  F♯  G♯  A
```

### Descending

```
A  G  F  E  D  C  B  A
```

This version avoids the large interval found in the harmonic minor scale and creates smoother melodic movement.

> **Note:** In jazz theory, the melodic minor scale is often played with the raised sixth and seventh in both ascending and descending directions.

---

## Comparing the Three Minor Scales

Using A as the tonic:

| Scale | Notes |
|--------|-------|
| Natural Minor | A B C D E F G A |
| Harmonic Minor | A B C D E F G♯ A |
| Melodic Minor (Ascending) | A B C D E F♯ G♯ A |

Notice that each version differs only in the sixth and seventh scale degrees.

---

## What Are Musical Modes?

Before the modern major and minor key system developed, music was often based on **modes**.

A **mode** is a scale created by starting on a different degree of the major scale while keeping the same notes.

Each mode has its own unique interval pattern and musical character.

---

## The Seven Traditional Modes

Using the C Major scale as the starting point:

| Mode | Notes |
|------|-------|
| Ionian | C D E F G A B |
| Dorian | D E F G A B C |
| Phrygian | E F G A B C D |
| Lydian | F G A B C D E |
| Mixolydian | G A B C D E F |
| Aeolian | A B C D E F G |
| Locrian | B C D E F G A |

Although these modes contain the same notes, each has a different tonic and therefore a different sound.

---

## Characteristics of the Modes

### Ionian

Equivalent to the major scale.

Bright and stable.

---

### Dorian

Minor with a raised sixth.

Often heard in jazz, blues, and folk music.

---

### Phrygian

Minor with a lowered second.

Creates a dark, dramatic, and often Spanish or Middle Eastern flavor.

---

### Lydian

Major with a raised fourth.

Dreamlike and bright.

Frequently used in film music.

---

### Mixolydian

Major with a lowered seventh.

Common in blues, rock, folk, and country music.

---

### Aeolian

Equivalent to the natural minor scale.

Melancholic and expressive.

---

### Locrian

Minor with a lowered second and lowered fifth.

Unstable and rarely used as the basis for an entire composition.

---

## When Are Modes Used?

Modes appear in many styles of music.

Examples include:

- Medieval and Renaissance music
- Jazz improvisation
- Folk music
- Rock music
- Film and video game soundtracks
- Progressive music

Rather than changing keys frequently, modal music often emphasizes the unique character of a single mode.

---

## Practice Examples

### Example 1

Construct the E Natural Minor scale.

**Answer:**

```
E  F♯  G  A  B  C  D  E
```

---

### Example 2

What is the relative minor of G Major?

**Answer:**

```
E Minor
```

---

### Example 3

What note changes when converting A Natural Minor to A Harmonic Minor?

**Answer:**

The seventh degree changes from:

```
G → G♯
```

---

### Example 4

Which mode is identical to the major scale?

**Answer:**

```
Ionian
```

---

### Example 5

Which mode is equivalent to the natural minor scale?

**Answer:**

```
Aeolian
```

---

## Key Takeaways

- The natural minor scale follows the pattern:
  - Whole
  - Half
  - Whole
  - Whole
  - Half
  - Whole
  - Whole
- Every major key has a relative minor that shares its key signature.
- Parallel major and minor keys share the same tonic but have different key signatures.
- The harmonic minor scale raises the seventh degree.
- The melodic minor scale raises the sixth and seventh degrees when ascending.
- Modes are alternative scale patterns derived from the major scale.
- The seven traditional modes each have their own musical character and applications.

---

## Summary

Minor scales expand the tonal possibilities of music by introducing moods and harmonic relationships that differ from those of the major scale. In this chapter, you learned how natural, harmonic, and melodic minor scales are constructed, how relative and parallel keys are related, and how musical modes provide additional tonal colors. Together, these scales and modes greatly increase the expressive palette available to composers and performers.

In the next chapter, you will learn how **chords** are built from scales and intervals, forming the harmonic foundation of most Western music.