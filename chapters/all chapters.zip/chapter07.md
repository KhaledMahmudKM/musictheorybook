# Chapter 7 — Chords

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what a chord is.
- Understand how chords are built using intervals.
- Construct major, minor, diminished, and augmented triads.
- Recognize suspended and power chords.
- Understand chord inversions.
- Read common chord symbols.

---

## Introduction

While a melody consists of notes played one after another, a **chord** is created when multiple notes are played at the same time.

Chords provide the harmonic foundation of music. They create feelings of stability, tension, excitement, and resolution, helping to support melodies and shape the emotional character of a piece.

Most Western music is built around chords, making them one of the most important topics in music theory.

---

## What Is a Chord?

A **chord** is a group of **three or more different notes** played simultaneously.

For example:

```
C  E  G
```

When played together, these notes form a **C Major chord**.

Although a chord normally contains at least three different notes, guitarists and other instrumentalists often omit or duplicate notes depending on the instrument and musical context.

---

## Building Chords

Most chords are built by stacking **thirds**.

Starting with a note called the **root**, we add notes that are a third and a fifth above it.

For example:

```
C
↓ Major Third
E
↓ Minor Third
G
```

This produces:

```
C  E  G
```

The three notes are called:

| Position | Name |
|----------|------|
| First note | Root |
| Second note | Third |
| Third note | Fifth |

These three-note chords are known as **triads**.

---

## Major Triads

A **major triad** consists of:

- Root
- Major Third
- Perfect Fifth

Formula:

```
Root + Major 3rd + Perfect 5th
```

Examples:

| Chord | Notes |
|-------|-------|
| C Major | C E G |
| G Major | G B D |
| D Major | D F♯ A |
| F Major | F A C |

Major chords are often described as sounding:

- Bright
- Stable
- Strong
- Happy

---

## Minor Triads

A **minor triad** consists of:

- Root
- Minor Third
- Perfect Fifth

Formula:

```
Root + Minor 3rd + Perfect 5th
```

Examples:

| Chord | Notes |
|-------|-------|
| A Minor | A C E |
| E Minor | E G B |
| D Minor | D F A |
| B Minor | B D F♯ |

Compared with a major chord, only the third changes.

Minor chords are commonly associated with sounds that are:

- Calm
- Emotional
- Reflective
- Mysterious

---

## Comparing Major and Minor Chords

Consider these two chords:

### C Major

```
C  E  G
```

### C Minor

```
C  E♭  G
```

The only difference is:

```
E → E♭
```

Lowering the third by one semitone changes the chord from major to minor.

---

## Diminished Triads

A **diminished triad** consists of:

- Root
- Minor Third
- Diminished Fifth

Formula:

```
Root + Minor 3rd + Diminished 5th
```

Examples:

| Chord | Notes |
|-------|-------|
| B Diminished | B D F |
| C♯ Diminished | C♯ E G |
| D Diminished | D F A♭ |

Diminished chords sound tense and unstable.

They are commonly used to create suspense before resolving to another chord.

---

## Augmented Triads

An **augmented triad** consists of:

- Root
- Major Third
- Augmented Fifth

Formula:

```
Root + Major 3rd + Augmented 5th
```

Examples:

| Chord | Notes |
|-------|-------|
| C Augmented | C E G♯ |
| F Augmented | F A C♯ |
| G Augmented | G B D♯ |

Augmented chords produce a bright but unsettled sound and often lead naturally to another chord.

---

## Triad Summary

| Chord Type | Formula |
|------------|---------|
| Major | Root – Major 3rd – Perfect 5th |
| Minor | Root – Minor 3rd – Perfect 5th |
| Diminished | Root – Minor 3rd – Diminished 5th |
| Augmented | Root – Major 3rd – Augmented 5th |

Notice that only the third and fifth determine the quality of the triad.

---

## Suspended Chords

A **suspended chord** replaces the third with another scale degree.

Because the third determines whether a chord is major or minor, suspended chords have a more open and neutral sound.

### Sus2 Chord

Formula:

```
Root + Major 2nd + Perfect 5th
```

Example:

```
C  D  G
```

---

### Sus4 Chord

Formula:

```
Root + Perfect 4th + Perfect 5th
```

Example:

```
C  F  G
```

Suspended chords often resolve to major or minor chords by moving the suspended note to the third.

---

## Power Chords

A **power chord** contains only:

- Root
- Perfect Fifth

Sometimes the root is doubled an octave higher.

Example:

```
C  G
```

or

```
C  G  C
```

Because there is no third, power chords are neither major nor minor.

Power chords are especially common in:

- Rock
- Heavy metal
- Punk music

Their simple structure creates a strong and powerful sound.

---

## Chord Inversions

Until now, the **root** has always been the lowest note.

This arrangement is called the **root position**.

A chord can also be rearranged so that another note is the lowest.

These arrangements are called **inversions**.

---

### Root Position

```
C
E
G
```

Lowest note:

```
C
```

---

### First Inversion

Move the root up one octave.

```
E
G
C
```

Lowest note:

```
E
```

---

### Second Inversion

Move the lowest note up another octave.

```
G
C
E
```

Lowest note:

```
G
```

Although the notes are in a different order, the chord is still C Major.

Inversions make chord progressions smoother by reducing large jumps between chords.

---

## Chord Symbols

Musicians often use abbreviated symbols instead of writing every note.

Common chord symbols include:

| Symbol | Meaning |
|--------|---------|
| C | C Major |
| Cm | C Minor |
| Cdim | C Diminished |
| Caug or C+ | C Augmented |
| Csus2 | C Suspended 2 |
| Csus4 | C Suspended 4 |
| C5 | C Power Chord |

These symbols are widely used in lead sheets, chord charts, and popular music.

---

## Chords Built from the Major Scale

Each degree of a major scale can be used to build a triad.

Using the C Major scale:

```
C  D  E  F  G  A  B
```

The resulting triads are:

| Scale Degree | Chord |
|--------------|-------|
| I | C Major |
| ii | D Minor |
| iii | E Minor |
| IV | F Major |
| V | G Major |
| vi | A Minor |
| vii° | B Diminished |

Notice the pattern:

```
Major
Minor
Minor
Major
Major
Minor
Diminished
```

This pattern is the same for every major key.

---

## Practice Examples

### Example 1

Construct a G Major chord.

**Answer:**

```
G  B  D
```

---

### Example 2

Construct an E Minor chord.

**Answer:**

```
E  G  B
```

---

### Example 3

Which note changes when C Major becomes C Minor?

**Answer:**

```
E → E♭
```

---

### Example 4

What notes form a Diminished B chord?

**Answer:**

```
B  D  F
```

---

### Example 5

What is the first inversion of C Major?

**Answer:**

```
E  G  C
```

---

## Key Takeaways

- A chord consists of three or more notes played together.
- Most chords are built by stacking thirds.
- A triad contains a root, a third, and a fifth.
- Major and minor chords differ only in the third.
- Diminished chords have a lowered fifth.
- Augmented chords have a raised fifth.
- Suspended chords replace the third with the second or fourth.
- Power chords contain only the root and fifth.
- Chord inversions change the lowest note while keeping the chord quality the same.
- Every major scale naturally produces a predictable pattern of triads.

---

## Summary

Chords provide the harmonic framework of music. In this chapter, you learned how triads are constructed from intervals, how major, minor, diminished, augmented, suspended, and power chords differ, and how inversions improve voice leading. You also saw how the notes of a major scale naturally generate a family of related chords that are used in countless musical compositions.

In the next chapter, you will expand these ideas by exploring **seventh and extended chords**, which add richness and complexity to harmony.