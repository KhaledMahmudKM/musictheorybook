# Chapter 5 — Major Scales

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what a musical scale is.
- Construct a major scale using whole and half steps.
- Identify the scale degrees of a major scale.
- Build major scales starting from different notes.
- Understand the relationship between key signatures and major scales.
- Use the Circle of Fifths to identify major keys.

---

## Introduction

A **scale** is a sequence of notes arranged in ascending or descending order of pitch.

Scales are one of the most important concepts in music theory because they form the foundation of:

- Melodies
- Harmony
- Chords
- Key signatures
- Musical improvisation

Although many different types of scales exist, the **major scale** is the most common and serves as the basis for understanding Western music.

---

## What Is a Major Scale?

A **major scale** consists of **seven different notes**, followed by the eighth note, which is the starting note repeated one octave higher.

For example:

```
C  D  E  F  G  A  B  C
```

The first and last notes have the same name but are one octave apart.

What makes a scale "major" is not the note it starts on, but the specific pattern of intervals between its notes.

---

## Whole-Step and Half-Step Pattern

Every major scale follows the same pattern of whole steps (W) and half steps (H):

```
W – W – H – W – W – W – H
```

Or visually:

```
1 → 2 → 3 → 4 → 5 → 6 → 7 → 8
 W   W   H   W   W   W   H
```

This pattern remains the same regardless of the starting note.

---

## Building the C Major Scale

Let's build the C Major scale.

Start with C.

Apply the major scale pattern:

```
C → D   (Whole)
D → E   (Whole)
E → F   (Half)
F → G   (Whole)
G → A   (Whole)
A → B   (Whole)
B → C   (Half)
```

Result:

```
C  D  E  F  G  A  B  C
```

Notice that the C Major scale contains **no sharps or flats**.

---

## Building Other Major Scales

When the starting note changes, accidentals are often needed to preserve the same whole-step and half-step pattern.

### G Major

Start with G.

```
G
↓ W
A
↓ W
B
↓ H
C
↓ W
D
↓ W
E
↓ W
F♯
↓ H
G
```

Result:

```
G  A  B  C  D  E  F♯  G
```

The G Major scale contains one sharp:

- F♯

---

### D Major

Applying the same pattern gives:

```
D  E  F♯  G  A  B  C♯  D
```

Sharps:

- F♯
- C♯

---

### F Major

Applying the major scale pattern gives:

```
F  G  A  B♭  C  D  E  F
```

Flats:

- B♭

---

## Why Are Sharps and Flats Needed?

Suppose we try to build a G Major scale without using sharps.

```
G  A  B  C  D  E  F  G
```

Check the interval pattern:

```
G → A  W
A → B  W
B → C  H
C → D  W
D → E  W
E → F  H   ❌
```

The pattern should end with:

```
W – H
```

instead of:

```
H – W
```

By raising F to F♯, the correct interval pattern is restored.

---

## Scale Degrees

Each note of a scale has a specific position called a **scale degree**.

Using the C Major scale:

```
C  D  E  F  G  A  B
```

The degrees are:

| Degree | Name |
|---------|----------------|
| 1 | Tonic |
| 2 | Supertonic |
| 3 | Mediant |
| 4 | Subdominant |
| 5 | Dominant |
| 6 | Submediant |
| 7 | Leading Tone |

The eighth note is simply the tonic repeated one octave higher.

These names are important because each degree has a characteristic musical function.

---

## Functions of the Scale Degrees

Each scale degree contributes differently to the sound of a key.

### Tonic (1)

The tonic is the "home" note.

Melodies often begin or end on the tonic because it provides a sense of stability and resolution.

---

### Dominant (5)

The dominant creates tension and naturally leads back to the tonic.

Many chord progressions rely on this relationship.

---

### Leading Tone (7)

The leading tone lies one semitone below the tonic.

Because of its close proximity, it creates a strong sense of movement toward the tonic.

For example:

```
B → C
```

The note B strongly "wants" to resolve to C.

---

## Key Signatures and Major Scales

Each major scale has a corresponding **key signature**.

Instead of writing accidentals repeatedly, the key signature places them at the beginning of the staff.

Examples:

| Major Key | Sharps/Flats |
|-----------|--------------|
| C Major | None |
| G Major | F♯ |
| D Major | F♯ C♯ |
| A Major | F♯ C♯ G♯ |
| F Major | B♭ |
| B♭ Major | B♭ E♭ |

Learning major scales naturally leads to learning key signatures.

---

## The Circle of Fifths

The **Circle of Fifths** organizes keys according to perfect fifths.

Moving **clockwise** adds one sharp each time.

```
C
↓
G
↓
D
↓
A
↓
E
↓
B
↓
F♯
↓
C♯
```

Moving **counterclockwise** adds one flat each time.

```
C
↓
F
↓
B♭
↓
E♭
↓
A♭
↓
D♭
↓
G♭
↓
C♭
```

The Circle of Fifths helps musicians:

- Identify key signatures.
- Understand relationships between keys.
- Transpose music.
- Build chord progressions.

You will revisit the Circle of Fifths in a later chapter when studying modulation.

---

## Practicing Major Scales

A good way to learn major scales is to:

1. Memorize the whole-step and half-step pattern.
2. Build scales beginning on different notes.
3. Identify the required sharps or flats.
4. Practice ascending and descending.
5. Play or sing the scales regularly.

Over time, recognizing major scales becomes almost automatic.

---

## Practice Examples

### Example 1

Construct the D Major scale.

Apply the major scale pattern.

**Answer:**

```
D  E  F♯  G  A  B  C♯  D
```

---

### Example 2

Which major scale has no sharps or flats?

**Answer:**

```
C Major
```

---

### Example 3

What is the fifth degree of the G Major scale?

```
G  A  B  C  D  E  F♯
```

**Answer:**

```
D
```

---

### Example 4

What is the seventh degree of the F Major scale?

```
F  G  A  B♭  C  D  E
```

**Answer:**

```
E
```

---

### Example 5

What interval pattern defines every major scale?

**Answer:**

```
Whole – Whole – Half – Whole – Whole – Whole – Half
```

---

## Key Takeaways

- A major scale contains seven unique notes followed by the octave.
- Every major scale follows the interval pattern:
  - Whole
  - Whole
  - Half
  - Whole
  - Whole
  - Whole
  - Half
- Accidentals preserve this interval pattern when starting on different notes.
- Each note of the scale has a specific name and musical function.
- Every major scale corresponds to a key signature.
- The Circle of Fifths organizes major keys according to their sharps and flats.

---

## Summary

Major scales form the foundation of Western music theory. In this chapter, you learned how every major scale is built from the same pattern of whole and half steps, regardless of its starting note. You also explored scale degrees, their musical functions, the relationship between major scales and key signatures, and the Circle of Fifths. These concepts provide the framework for understanding melodies, harmony, and chord construction.

In the next chapter, you will learn about **minor scales and musical modes**, expanding your understanding of the different tonal colors used in music.