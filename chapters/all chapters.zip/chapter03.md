# Chapter 3 — Rhythm and Time

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain the concepts of beat, pulse, and rhythm.
- Understand tempo and how it is measured.
- Recognize common note values and rests.
- Interpret simple time signatures.
- Distinguish between simple and compound meter.
- Understand syncopation.
- Count basic rhythms.

---

## Introduction

If **pitch** determines *what* notes we hear, **rhythm** determines *when* we hear them.

Rhythm gives music its movement and structure. Without rhythm, music would be a collection of notes with no sense of timing or flow.

Whether it is a classical symphony, a jazz improvisation, or a rock song, every piece of music relies on rhythm.

---

## Beat

A **beat** is the regular pulse that underlies a piece of music. It is the steady "heartbeat" that listeners naturally tap their feet or clap their hands to.

For example, if you clap steadily once every second, each clap represents one beat.

Although the beat usually remains constant, the notes played by the musicians may occur on the beat, between beats, or may last for several beats.

---

## Pulse

The terms **pulse** and **beat** are often used interchangeably.

The pulse is the underlying, evenly spaced timing that provides a framework for the music.

Think of a clock ticking every second:

```
Tick   Tick   Tick   Tick
```

Each tick is like a musical beat.

The rhythm of a melody is created by arranging notes around this steady pulse.

---

## Rhythm

**Rhythm** is the pattern of long and short sounds organized over the beat.

For example, both of the following rhythms may use the same four beats, but they sound very different:

```
Beat:    1    2    3    4

Rhythm A:
♪    ♪    ♪    ♪

Rhythm B:
♩       ♫    ♩
```

The beat stays the same, while the rhythm changes.

---

## Tempo

**Tempo** is the speed at which music is performed.

Tempo is usually measured in **beats per minute (BPM)**.

Examples:

| Tempo | Approximate BPM |
|--------|----------------:|
| Largo | 40–60 |
| Adagio | 66–76 |
| Andante | 76–108 |
| Moderato | 108–120 |
| Allegro | 120–168 |
| Presto | 168–200+ |

For example:

- 60 BPM means one beat every second.
- 120 BPM means two beats every second.

Many modern pieces specify the tempo numerically (for example, **♩ = 120**), while others use traditional Italian terms.

---

## Note Values

Each note has a duration relative to the beat.

The most common note values are:

| Note | Name | Duration |
|------|------|---------:|
| 𝅝 | Whole note | 4 beats |
| 𝅗𝅥 | Half note | 2 beats |
| ♩ | Quarter note | 1 beat |
| ♪ | Eighth note | 1/2 beat |
| ♬ | Sixteenth note | 1/4 beat |

If the quarter note represents one beat:

```
Whole Note

|--------4 beats--------|
```

```
Half Notes

|----2----|----2----|
```

```
Quarter Notes

|1|2|3|4|
```

```
Eighth Notes

|1 &|2 &|3 &|4 &|
```

Each shorter note divides the beat into smaller equal parts.

> **Note:** The actual duration of a note depends on the tempo. A quarter note lasts longer at 60 BPM than at 120 BPM.

---

## Dotted Notes

A **dot** placed after a note increases its duration by **half of its original value**.

Examples:

| Note | Duration |
|------|---------:|
| Half note | 2 beats |
| Dotted half note | 3 beats |
| Quarter note | 1 beat |
| Dotted quarter note | 1½ beats |
| Eighth note | 1/2 beat |
| Dotted eighth note | 3/4 beat |

For example:

```
Quarter Note

1 beat
```

```
Dotted Quarter Note

1 + 1/2 = 1.5 beats
```

Dotted notes are commonly used in compound meters and many musical styles.

---

## Ties

A **tie** connects two notes of the **same pitch**, combining their durations into a single sustained note.

For example:

```
Quarter Note + Quarter Note

♩  ♩
```

With a tie:

```
♩‿♩
```

This produces one note lasting **2 beats**.

A tie should not be confused with a **slur**, which connects notes of different pitches and indicates smooth performance rather than longer duration.

---

## Rests

A **rest** indicates silence.

Like notes, rests have different durations.

| Rest | Duration |
|------|---------:|
| Whole rest | 4 beats |
| Half rest | 2 beats |
| Quarter rest | 1 beat |
| Eighth rest | 1/2 beat |
| Sixteenth rest | 1/4 beat |

Silence is just as important as sound in creating musical rhythm.

---

## Measures (Bars)

Music is divided into equal sections called **measures**, also known as **bars**.

Measures help organize music and make it easier to read.

Vertical bar lines separate one measure from the next.

Example:

```
| 1 2 3 4 | 1 2 3 4 | 1 2 3 4 |
```

Each measure contains a specific number of beats determined by the **time signature**.

---

## Time Signatures

A **time signature** tells us how beats are organized within each measure.

It is written as two numbers:

```
Top Number
-----------
Bottom Number
```

The **top number** tells us how many beats are in each measure.

The **bottom number** tells us which note value represents one beat.

Common time signatures include:

| Time Signature | Meaning |
|---------------|---------|
| 4/4 | Four quarter-note beats per measure |
| 3/4 | Three quarter-note beats per measure |
| 2/4 | Two quarter-note beats per measure |
| 6/8 | Six eighth-note beats per measure |

For example:

```
4/4

1   2   3   4
```

```
3/4

1   2   3
```

```
2/4

1   2
```

---

## Simple Meter

A **simple meter** divides each beat into **two equal parts**.

Common examples include:

- 2/4
- 3/4
- 4/4

For example, in 4/4 time:

```
Quarter Note

1 beat
```

can be divided into:

```
Two Eighth Notes

1 & 
```

---

## Compound Meter

A **compound meter** divides each beat into **three equal parts**.

The most common example is **6/8**.

Instead of counting:

```
1 2 3 4 5 6
```

musicians often feel:

```
1-la-li   2-la-li
```

or

```
ONE-and-a   TWO-and-a
```

Although there are six eighth notes in each measure, they are grouped into **two main beats**.

Compound meter creates a flowing, lilting feel that is common in folk music, marches, and ballads.

---

## Syncopation

Normally, the strongest accents occur on the main beats.

**Syncopation** occurs when emphasis is placed on weak beats or between beats.

For example, in 4/4 time:

```
Strong   Weak   Medium   Weak

1    2    3    4
```

A syncopated rhythm might emphasize:

```
1   &   2   &   3   &   4   &
```

instead of only the numbered beats.

Syncopation creates energy, surprise, and forward motion. It is common in jazz, rock, pop, funk, and Latin music.

---

## Counting Rhythms

Learning to count rhythms helps musicians perform accurately.

In simple meter, quarter notes are often counted as:

```
1   2   3   4
```

Eighth notes:

```
1 & 2 & 3 & 4 &
```

Sixteenth notes:

```
1 e & a
2 e & a
3 e & a
4 e & a
```

Speaking the counts while clapping the rhythm is an effective way to develop rhythmic accuracy.

---

## Practice Examples

### Example 1

How many beats does a half note receive in 4/4 time?

**Answer:** 2 beats.

---

### Example 2

How many quarter notes fit into one whole note?

**Answer:** 4 quarter notes.

---

### Example 3

How many eighth notes fit into one half note?

**Answer:** 4 eighth notes.

---

### Example 4

What does a 3/4 time signature indicate?

**Answer:** Each measure contains three quarter-note beats.

---

### Example 5

What is syncopation?

**Answer:** Emphasizing weak beats or off-beats instead of the normally accented beats.

---

## Key Takeaways

- Rhythm organizes sounds over time.
- The beat is the steady pulse of the music.
- Tempo determines the speed of the beat.
- Note values indicate how long notes are held.
- Dotted notes increase a note's duration by half of its original value.
- Ties combine the durations of notes with the same pitch.
- Rests indicate silence.
- Measures divide music into equal sections.
- Time signatures specify how beats are grouped.
- Simple meter divides beats into two parts, while compound meter divides them into three.
- Syncopation places emphasis on unexpected parts of the beat.
- Counting rhythms aloud improves timing and accuracy.

---

## Summary

Rhythm provides the sense of movement and timing in music. In this chapter, you learned how beats form the foundation of rhythm, how tempo controls speed, how note values and rests determine duration, and how time signatures organize beats into measures. You also explored simple and compound meter, dotted notes, ties, and syncopation. Together, these concepts allow musicians to read, perform, and create rhythmic patterns with confidence.

In the next chapter, you will learn how to read standard musical notation, including the staff, clefs, note names, key signatures, dynamics, and other symbols used in sheet music.