# Chapter 4 — Reading Music

## Learning Objectives

By the end of this chapter, you should be able to:

- Understand the purpose of standard musical notation.
- Identify the staff, bar lines, and measures.
- Recognize the treble and bass clefs.
- Read notes on the staff.
- Understand ledger lines.
- Use accidentals correctly.
- Interpret key signatures.
- Recognize common dynamics and articulation markings.
- Identify common musical symbols.

---

## Introduction

Musical notation is a written language that allows musicians to record and share music. Just as books use letters and punctuation to communicate ideas, sheet music uses notes, symbols, and markings to describe what should be played and how it should sound.

Although learning to read music takes practice, understanding the notation system makes it much easier to learn new pieces, communicate with other musicians, and study music theory.

---

## The Musical Staff

The **staff** (or **stave**) is the foundation of written music. It consists of **five horizontal lines** and the **four spaces** between them.

```
-----------------
-----------------
-----------------
-----------------
-----------------
```

Notes are placed on either the lines or the spaces.

Higher notes are written higher on the staff, while lower notes are written lower.

---

## Measures and Bar Lines

The staff is divided into sections called **measures** (or **bars**).

Vertical lines called **bar lines** separate one measure from the next.

Example:

```
| ♩ ♩ ♩ ♩ | ♩ ♩ ♩ ♩ |
```

The number of beats contained in each measure is determined by the **time signature**.

Measures make music easier to read and help performers keep their place.

---

## Clefs

A **clef** tells us which pitches correspond to the lines and spaces of the staff.

The two most common clefs are:

- Treble clef
- Bass clef

Different instruments use different clefs depending on their pitch range.

---

## The Treble Clef

The **treble clef** (also called the **G clef**) is used for higher-pitched instruments and voices.

Examples include:

- Violin
- Flute
- Trumpet
- Clarinet
- Right hand of the piano
- Most vocal melodies

### Notes on the Lines

From bottom to top:

```
E  G  B  D  F
```

A common mnemonic is:

> **Every Good Boy Deserves Fruit**

(You may also encounter the traditional phrase *Every Good Boy Deserves Favour*.)

### Notes in the Spaces

From bottom to top:

```
F  A  C  E
```

These spell the word:

> **FACE**

---

## The Bass Clef

The **bass clef** (also called the **F clef**) is used for lower-pitched instruments and voices.

Examples include:

- Bass guitar
- Tuba
- Cello
- Bassoon
- Left hand of the piano
- Bass voice

### Notes on the Lines

From bottom to top:

```
G  B  D  F  A
```

One common mnemonic is:

> **Good Boys Do Fine Always**

### Notes in the Spaces

From bottom to top:

```
A  C  E  G
```

A common mnemonic is:

> **All Cows Eat Grass**

---

## Ledger Lines

The five-line staff cannot represent every musical note.

When notes extend beyond the staff, short additional lines called **ledger lines** are used.

Example:

```
      ●
-----|-----
```

Ledger lines allow notation to continue above or below the staff while remaining easy to read.

---

## Middle C

**Middle C** is an important reference point in music notation.

It lies between the treble and bass staves.

On the piano, Middle C is located near the center of the keyboard.

In grand staff notation:

- It appears below the treble staff using one ledger line.
- It appears above the bass staff using one ledger line.

Because of its central position, Middle C is often one of the first notes beginners learn.

---

## The Grand Staff

Piano music is usually written on a **grand staff**, which combines:

- A treble staff
- A bass staff

These two staves are connected by a brace and share the same bar lines.

Typically:

- The right hand plays notes on the treble staff.
- The left hand plays notes on the bass staff.

The grand staff provides a wide enough range to represent nearly the entire keyboard.

---

## Note Names on the Staff

As notes move upward on the staff, they follow the repeating musical alphabet:

```
A B C D E F G
```

After G, the sequence repeats:

```
A B C D E F G A ...
```

Each move from one line to the next space (or vice versa) advances to the next letter.

---

## Accidentals

Sometimes a note must be raised or lowered.

This is indicated using **accidentals**.

| Symbol | Name | Effect |
|--------|------|--------|
| ♯ | Sharp | Raise the note by one semitone |
| ♭ | Flat | Lower the note by one semitone |
| ♮ | Natural | Cancel a previous sharp or flat |

Unless otherwise indicated, an accidental applies only:

- To notes of the same pitch within the current measure.
- It is cancelled automatically at the next bar line.

Example:

```
| F♯  G  F♯ | F |
```

The last F is natural because it is in a new measure.

---

## Key Signatures

Rather than writing the same accidental repeatedly throughout a piece, composers place **key signatures** at the beginning of the staff.

A key signature indicates which notes are consistently sharp or flat throughout the music.

Examples:

| Key Signature | Meaning |
|--------------|---------|
| No sharps or flats | C Major / A Minor |
| One sharp (F♯) | G Major / E Minor |
| One flat (B♭) | F Major / D Minor |

You will study keys and scales in greater detail in later chapters.

---

## Dynamics

**Dynamics** indicate how loudly or softly music should be played.

Common dynamic markings include:

| Symbol | Meaning |
|--------|---------|
| pp | Very soft |
| p | Soft |
| mp | Moderately soft |
| mf | Moderately loud |
| f | Loud |
| ff | Very loud |

Composers may also indicate gradual changes in volume.

| Symbol | Meaning |
|--------|---------|
| \< | Crescendo (gradually louder) |
| \> | Diminuendo or Decrescendo (gradually softer) |

Dynamics add expression and emotional contrast to music.

---

## Articulations

**Articulations** describe how individual notes should be performed.

Common articulation markings include:

| Symbol | Meaning |
|--------|---------|
| • | Staccato (short and detached) |
| — | Tenuto (held for full value) |
| Accent (>) | Play with emphasis |
| Slur | Play notes smoothly and connected |

The same sequence of notes can sound very different depending on the articulations used.

---

## Repeat Signs

Music often contains repeated sections.

The most common repeat sign is:

```
:||
||:
```

A performer repeats the music between the matching repeat signs.

Other common repeat instructions include:

- **D.C. (Da Capo)** — Return to the beginning.
- **D.S. (Dal Segno)** — Return to the sign (𝄋).
- **Fine** — End here.
- **Coda (𝄌)** — Jump to the ending section.

These markings reduce the amount of repeated notation on the page.

---

## Common Musical Symbols

Besides notes and rests, sheet music may include many additional symbols.

Some common examples include:

| Symbol | Meaning |
|--------|---------|
| ♯ | Sharp |
| ♭ | Flat |
| ♮ | Natural |
| 𝄐 | Fermata (hold longer than written) |
| 8va | Play one octave higher |
| 8vb | Play one octave lower |
| Tr | Trill |
| Ped. | Press the piano sustain pedal |

Different styles of music may use additional markings, but these are among the most frequently encountered.

---

## Practice Examples

### Example 1

What are the notes on the lines of the treble clef?

**Answer:** E, G, B, D, F.

---

### Example 2

What are the notes in the spaces of the bass clef?

**Answer:** A, C, E, G.

---

### Example 3

What is the purpose of a key signature?

**Answer:** It indicates which notes are consistently sharp or flat throughout a piece of music.

---

### Example 4

What does the marking **mf** mean?

**Answer:** Moderately loud.

---

### Example 5

What does a staccato marking indicate?

**Answer:** The note should be played short and detached.

---

## Key Takeaways

- The staff consists of five lines and four spaces.
- Clefs assign pitches to the staff.
- The treble clef is generally used for higher pitches, while the bass clef is used for lower pitches.
- Ledger lines extend the range of the staff.
- Middle C connects the treble and bass staves.
- The grand staff combines the treble and bass staves for instruments such as the piano.
- Accidentals temporarily raise or lower notes.
- Key signatures identify the sharps or flats used throughout a piece.
- Dynamics indicate volume.
- Articulations describe how notes should be performed.
- Musical symbols provide additional instructions to the performer.

---

## Summary

Standard musical notation provides a universal way to read and write music. In this chapter, you learned how the staff organizes notes, how clefs determine pitch, how ledger lines extend the musical range, and how accidentals and key signatures modify notes. You also explored dynamics, articulations, repeat signs, and other common musical symbols that help performers interpret a piece accurately and expressively.

In the next chapter, you will learn how **major scales** are constructed and how they form the basis of keys, melodies, and harmony.