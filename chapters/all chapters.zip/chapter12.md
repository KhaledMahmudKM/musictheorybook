# Chapter 12 — Musical Form

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what musical form is.
- Identify common structural building blocks (motif, phrase, section).
- Understand binary, ternary, and rondo forms.
- Recognize verse–chorus structure.
- Understand theme and variations.
- Identify the basics of sonata form.
- Analyze simple structural patterns in music.

---

## Introduction

Music is not only organized by notes, chords, and rhythm—it is also organized over time into **larger structures**.

This overall structure is called **musical form**.

Form helps music feel:

- Coherent
- Balanced
- Predictable (in a good way)
- Emotionally meaningful

Just as sentences form paragraphs and paragraphs form essays, musical ideas are grouped into phrases, sections, and complete forms.

---

## Building Blocks of Form

Before understanding full structures, we need to understand the smaller parts that make them up.

---

## Motif

A **motif** is the smallest identifiable musical idea.

Example:

```
C  D  E
```

Motifs are often repeated, varied, and developed throughout a piece.

---

## Phrase

A **phrase** is a complete musical thought, similar to a sentence.

Example:

```
C D E F | G A B C
```

A phrase often feels like it ends with a pause or resolution.

---

## Section

A **section** is a larger musical unit made of multiple phrases.

Sections are often labeled:

- A section
- B section
- Chorus
- Verse

---

## Binary Form (AB)

**Binary form** consists of two contrasting sections:

```
A → B
```

Characteristics:

- Section A presents main material.
- Section B contrasts with A.
- Both sections may be repeated.

Example structure:

```
A A B B
```

Common in:

- Baroque dance music
- Simple classical pieces
- Folk tunes

---

## Ternary Form (ABA)

**Ternary form** consists of three sections:

```
A → B → A
```

Characteristics:

- A section returns at the end.
- B provides contrast.
- Creates balance and symmetry.

Example:

```
A (theme) → B (contrast) → A (return)
```

Common in:

- Classical minuets
- Lullabies
- Romantic piano pieces

---

## Rondo Form (ABACA)

**Rondo form** features a recurring main theme:

```
A → B → A → C → A
```

Characteristics:

- A section keeps returning.
- Contrasting episodes (B, C, etc.) appear between returns.

Rondo creates a sense of familiarity mixed with variety.

Common in:

- Classical finales
- Virtuosic pieces
- Light, playful music

---

## Theme and Variations

In **theme and variations**, a main theme is presented and then altered in different ways.

Structure:

```
Theme → Variation 1 → Variation 2 → Variation 3 ...
```

Variations may change:

- Rhythm
- Harmony
- Tempo
- Key
- Texture
- Ornamentation

Example:

```
Theme:    C D E F G
Variation: C E D G F (rhythmic change)
```

This form shows creativity while keeping a recognizable core idea.

---

## Verse–Chorus Form

One of the most common forms in modern music.

Structure:

```
Verse → Chorus → Verse → Chorus → Bridge → Chorus
```

### Verse

- Tells the story
- Changes between repetitions

### Chorus

- Contains main message
- Usually most memorable section

### Bridge

- Provides contrast
- Often introduces new harmony or mood

Common in:

- Pop
- Rock
- Hip-hop
- Contemporary music

---

## Strophic Form

In **strophic form**, the same music repeats for different lyrics:

```
A → A → A
```

Each verse uses the same melody.

Common in:

- Hymns
- Folk songs
- Traditional music

---

## Through-Composed Form

In **through-composed music**, there is little or no repetition:

```
A → B → C → D
```

Each section is new.

Characteristics:

- Continuous development
- No repeated chorus or section

Common in:

- Art songs (Lieder)
- Programmatic music
- Narrative-driven compositions

---

## Sonata Form (Overview)

**Sonata form** is one of the most important structures in classical music.

It has three main sections:

---

## Exposition

Introduces main themes:

- First theme (usually in tonic key)
- Second theme (in a different key)

Example:

```
Theme 1 (C major) → Transition → Theme 2 (G major)
```

---

## Development

- Themes are altered, fragmented, or explored
- Frequent modulation
- Creates tension and instability

---

## Recapitulation

- Returns to main themes
- Both themes usually in tonic key
- Provides resolution

Structure:

```
Exposition → Development → Recapitulation
```

Often used in:

- Symphonies
- Sonatas
- Concertos

---

## Musical Form and Emotion

Form is not just structure—it shapes emotional experience:

- Repetition creates familiarity
- Contrast creates interest
- Return creates satisfaction
- Development creates tension

Good form balances:

```
Unity + Variety
```

---

## Listening for Form

To identify form in music, listen for:

- Repeated sections
- Changes in melody or harmony
- Returns of main themes
- Contrasting middle sections
- Climaxes and resolutions

Even without notation, the structure can often be felt intuitively.

---

## Practice Examples

### Example 1

What is musical form?

**Answer:**
The overall structure of a piece of music over time.

---

### Example 2

What is binary form?

**Answer:**
A structure with two sections (A and B).

---

### Example 3

What is the structure of ternary form?

**Answer:**
A → B → A

---

### Example 4

What is the main feature of rondo form?

**Answer:**
A recurring main theme (A) alternating with contrasting sections.

---

### Example 5

What are the three main sections of sonata form?

**Answer:**
Exposition, Development, Recapitulation.

---

## Key Takeaways

- Musical form is the large-scale structure of a piece.
- Motifs, phrases, and sections are the building blocks of form.
- Binary form has two sections (A–B).
- Ternary form has three sections (A–B–A).
- Rondo form features a recurring main theme.
- Theme and variations modify a central idea.
- Verse–chorus form is common in modern popular music.
- Sonata form consists of exposition, development, and recapitulation.
- Form balances repetition and contrast to shape musical experience.

---

## Summary

Musical form organizes music into meaningful large-scale structures. In this chapter, you learned how small ideas like motifs and phrases combine into larger sections, and how those sections form patterns such as binary, ternary, rondo, and verse–chorus structures. You also explored theme and variations, strophic and through-composed forms, and the classical sonata form.

In the next chapter, you will learn how to **apply all the concepts from this book** to analyze, create, and understand real music in practice.