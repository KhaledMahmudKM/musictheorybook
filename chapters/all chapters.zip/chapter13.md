# Chapter 13 — Applying Music Theory

## Learning Objectives

By the end of this chapter, you should be able to:

- Apply music theory concepts to real music.
- Analyze melodies, chords, and chord progressions.
- Identify key, scale, and harmony in simple songs.
- Transpose music to different keys.
- Build basic chord progressions.
- Use theory to support songwriting and improvisation.
- Develop a practical practice strategy for continued learning.

---

## Introduction

At this point, you have learned the core building blocks of music theory:

- Notes, intervals, and scales  
- Rhythm and notation  
- Chords and harmony  
- Progressions and form  

However, music theory is not meant to stay abstract. Its real value comes from **application**—understanding and creating real music.

This chapter focuses on how all these concepts connect in practice.

---

## Analyzing a Simple Song

Let’s walk through a basic analysis process.

### Step 1 — Identify the Key

Look for:

- The tonic chord (home feeling)
- The final chord
- The key signature

Example:

If a song ends on **C major** and frequently returns to it, the key is likely:

```
C Major
```

---

### Step 2 — Identify the Chords

Suppose the progression is:

```
C → G → Am → F
```

We can analyze this in C major:

| Chord | Function |
|-------|----------|
| C | I (Tonic) |
| G | V (Dominant) |
| Am | vi (Submediant) |
| F | IV (Subdominant) |

---

### Step 3 — Understand the Function

Now interpret the movement:

```
I → V → vi → IV
```

This creates:

- Stability (I)
- Tension (V)
- Emotional shift (vi)
- Resolution support (IV)

This is one of the most common progressions in modern music.

---

## Building Your Own Chord Progressions

A simple way to write music is to start with common progressions.

### Example Progressions

#### Basic Pop Progression

```
I → V → vi → IV
```

In C major:

```
C → G → Am → F
```

---

#### Simple Rock Progression

```
I → IV → V
```

In G major:

```
G → C → D
```

---

#### Emotional Progression

```
vi → IV → I → V
```

In C major:

```
Am → F → C → G
```

---

## Writing a Melody Over Chords

A good melody usually follows the underlying harmony.

### Step 1 — Use chord tones

Over C major (C–E–G), a melody might use:

```
C  E  G
```

### Step 2 — Add passing tones

```
C  D  E  G  E  D  C
```

### Step 3 — Match strong beats

Strong beats often align with chord tones:

- Beat 1 → chord tone
- Weak beats → passing or decorative notes

---

## Transposing Music

**Transposition** means moving a piece of music into a different key while preserving its structure.

---

### Example

Original in C major:

```
C → G → Am → F
```

Transpose to G major:

| C | G |
| G | D |
| Am | Em |
| F | C |

Result:

```
G → D → Em → C
```

---

### Why Transpose?

- To fit a singer’s vocal range
- To simplify playing on an instrument
- To match ensemble instruments
- To change musical mood slightly

---

## Using the Circle of Fifths in Practice

The Circle of Fifths helps you:

- Find related chords quickly
- Predict chord movements
- Choose keys for modulation

### Example

If you are in C major:

- G major is a strong resolution (V)
- F major provides stability (IV)
- A minor gives emotional contrast (vi)

---

## Improvisation Basics

Improvisation is creating music in real time.

### Step 1 — Choose a scale

Example:

```
C Major scale: C D E F G A B
```

---

### Step 2 — Use chord tones

If the chord is C major:

- Focus on C, E, G

---

### Step 3 — Add movement

- Use passing tones
- Repeat motifs
- Vary rhythm

Example idea:

```
E  G  A  G  E  D  C
```

---

## Ear Training (Practical Use)

Music theory becomes much more powerful when combined with listening.

Try to recognize:

- Major vs minor chords
- Simple intervals (3rd, 5th, octave)
- Common progressions (I–V–vi–IV)
- Cadences (especially V → I)

Even basic recognition improves musical understanding significantly.

---

## Common Practice Strategies

To improve your understanding of music theory:

### 1. Play scales daily
- Major and minor scales
- Hands or instruments

---

### 2. Learn chord shapes
- Major, minor, seventh chords
- Practice transitions

---

### 3. Analyze real songs
Ask:
- What key is it in?
- What chords are used?
- How does it end?

---

### 4. Write short progressions
Start simple:
```
C → Am → F → G
```

Then build melodies on top.

---

### 5. Copy and transform music
- Transpose songs
- Change rhythms
- Modify melodies

---

## Common Beginner Mistakes

### 1. Memorizing instead of understanding
Music theory is patterns, not lists.

---

### 2. Ignoring rhythm
Even simple melodies fail without rhythmic structure.

---

### 3. Overcomplicating harmony
Most popular music uses simple progressions.

---

### 4. Forgetting resolution
Music almost always returns to a tonal center.

---

## Putting Everything Together

A complete musical idea combines:

- **Harmony** (chords)
- **Melody** (notes over chords)
- **Rhythm** (timing)
- **Form** (structure)

Example:

```
Chord: C → G → Am → F
Melody: C D E | G E D | A G E | F E C
Rhythm: steady 4/4 pulse
Form: repeating verse structure
```

---

## Practice Examples

### Example 1

What is the key of a song that ends on G major and uses F♯ consistently?

**Answer:**
G Major

---

### Example 2

Transpose C → F → G → C into D major.

**Answer:**
D → G → A → D

---

### Example 3

What are the chord tones of A minor?

**Answer:**
A, C, E

---

### Example 4

What is improvisation in music?

**Answer:**
Creating music spontaneously using scales, chords, and rhythm.

---

### Example 5

What is the purpose of analyzing songs?

**Answer:**
To understand how music theory is applied in real compositions.

---

## Key Takeaways

- Music theory becomes powerful when applied to real music.
- Songs can be analyzed using key, chords, and function.
- Common progressions repeat across many genres.
- Transposition preserves structure while changing key.
- Melody should align with harmony and rhythm.
- Improvisation uses scales, chord tones, and motifs.
- Ear training strengthens practical understanding.
- Simple patterns are the foundation of most music.

---

## Final Summary

Music theory is not just a set of rules—it is a tool for understanding and creating music. Across this book, you have learned how notes form intervals, how scales create keys, how chords build harmony, how progressions create movement, and how form organizes entire compositions.

In this final chapter, you learned how to apply all of these ideas in real musical situations: analyzing songs, writing progressions, creating melodies, transposing music, and beginning improvisation.

With this foundation, you can now continue exploring more advanced topics such as:

- Counterpoint  
- Jazz harmony  
- Orchestration  
- Composition  
- Music production  

Music theory is not an endpoint—it is a starting point for deeper musical exploration.