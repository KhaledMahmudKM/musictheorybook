# Appendix — Music Theory Reference Guide

## A. Note Names (Scientific Pitch Notation)

Standard note naming in Western music:

```
C  C♯/D♭  D  D♯/E♭  E  F  F♯/G♭  G  G♯/A♭  A  A♯/B♭  B
```

Notes repeat in higher or lower octaves:

```
C1, C2, C3, C4 (middle C), C5, C6, C7
```

---

## B. Intervals (Quick Reference)

Intervals describe the distance between two notes.

| Interval | Semitones | Example (C root) |
|----------|----------|------------------|
| Minor 2nd | 1 | C → C♯ |
| Major 2nd | 2 | C → D |
| Minor 3rd | 3 | C → E♭ |
| Major 3rd | 4 | C → E |
| Perfect 4th | 5 | C → F |
| Tritone | 6 | C → F♯ |
| Perfect 5th | 7 | C → G |
| Minor 6th | 8 | C → A♭ |
| Major 6th | 9 | C → A |
| Minor 7th | 10 | C → B♭ |
| Major 7th | 11 | C → B |
| Octave | 12 | C → C |

---

## C. Major Scale Formula

```
W – W – H – W – W – W – H
```

Example (C Major):

```
C D E F G A B C
```

---

## D. Natural Minor Scale Formula

```
W – H – W – W – H – W – W
```

Example (A Minor):

```
A B C D E F G A
```

---

## E. Harmonic Minor Scale Formula

```
W – H – W – W – H – W+H – H
```

Example:

```
A B C D E F G♯ A
```

---

## F. Chord Quality Quick Guide

### Triads

| Type | Formula |
|------|--------|
| Major | 1 – 3 – 5 |
| Minor | 1 – ♭3 – 5 |
| Diminished | 1 – ♭3 – ♭5 |
| Augmented | 1 – 3 – ♯5 |

---

### Seventh Chords

| Type | Formula |
|------|--------|
| Major 7 | 1 – 3 – 5 – 7 |
| Dominant 7 | 1 – 3 – 5 – ♭7 |
| Minor 7 | 1 – ♭3 – 5 – ♭7 |
| Half-diminished 7 | 1 – ♭3 – ♭5 – ♭7 |
| Diminished 7 | 1 – ♭3 – ♭5 – ♭♭7 |

---

## G. Scale Degree Names

| Degree | Name |
|--------|------|
| 1 | Tonic |
| 2 | Supertonic |
| 3 | Mediant |
| 4 | Subdominant |
| 5 | Dominant |
| 6 | Submediant |
| 7 | Leading Tone |

---

## H. Modes (Quick Reference)

Built from C major:

| Mode | Starting Note | Character |
|------|--------------|-----------|
| Ionian | C | Major |
| Dorian | D | Minor (bright) |
| Phrygian | E | Dark |
| Lydian | F | Bright, dreamy |
| Mixolydian | G | Bluesy major |
| Aeolian | A | Natural minor |
| Locrian | B | Unstable |

---

## I. Common Chord Progressions

### Pop Progressions

```
I – V – vi – IV
vi – IV – I – V
I – IV – V
```

---

### Jazz Progressions

```
ii – V – I
I – vi – ii – V
```

---

### Blues (12-bar)

```
I – I – I – I
IV – IV – I – I
V – IV – I – I
```

---

## J. Cadences

| Type | Pattern | Feeling |
|------|--------|---------|
| Authentic | V → I | Strong resolution |
| Plagal | IV → I | Soft resolution |
| Half | ends on V | Unfinished |
| Deceptive | V → vi | Surprise |

---

## K. Key Relationships

### Closely Related Keys (C Major)

- G Major (dominant)
- F Major (subdominant)
- A Minor (relative minor)

---

## L. Circle of Fifths (Text Version)

```
C
G  F
D  B♭
A  E♭
E  A♭
B  D♭
F♯ G♭
```

---

## M. Roman Numeral System

| Symbol | Meaning |
|--------|--------|
| I | Major tonic |
| i | Minor tonic |
| V | Dominant |
| v | Minor dominant |
| vii° | Diminished leading tone chord |

---

## N. Common Chord Symbols

| Symbol | Meaning |
|--------|--------|
| C | C major |
| Cm | C minor |
| C7 | Dominant seventh |
| Cmaj7 | Major seventh |
| Cm7 | Minor seventh |
| Cdim | Diminished |
| Caug | Augmented |
| Csus2 / Csus4 | Suspended chords |
| C5 | Power chord |
| Cadd9 | Added ninth |
| C/E | Slash chord |

---

## O. Basic Analysis Checklist

When analyzing a song:

1. Identify key
2. Find tonic chord
3. List chord progression
4. Assign Roman numerals
5. Look for cadences
6. Identify form (AABA, verse–chorus, etc.)
7. Check for modulation or borrowed chords

---

## P. Basic Composition Checklist

When writing music:

1. Choose a key
2. Pick a chord progression
3. Build melody using chord tones
4. Add passing tones for movement
5. Use repetition + variation
6. Define a form (verse, chorus, etc.)

---

## Q. Glossary (Quick Definitions)

- **Harmony**: Chords and their progression
- **Melody**: Sequence of single notes
- **Rhythm**: Timing of notes
- **Tonic**: Home note/chord
- **Modulation**: Key change
- **Cadence**: Musical ending
- **Interval**: Distance between notes
- **Triad**: Three-note chord
- **Scale**: Ordered set of notes

---

## Final Note

This appendix is meant as a quick-reference companion to the main chapters. Music theory becomes most powerful when these concepts are combined in real musical analysis, listening, and composition.

Return to earlier chapters whenever needed—music theory is best learned cyclically, not linearly.