# Chapter 10 — Melody

## Learning Objectives

By the end of this chapter, you should be able to:

- Explain what a melody is.
- Identify motifs, phrases, and sequences.
- Understand melodic contour.
- Recognize tension and release in melody.
- Understand how melody interacts with harmony.
- Write simple melodic ideas.

---

## Introduction

If harmony is the foundation of music, then **melody is the part you usually remember**.

A melody is a sequence of single notes arranged in a meaningful and expressive way. It is often the most recognizable element of a piece of music, whether it is a song you can sing or a theme from a film.

Melody works together with harmony and rhythm to create musical expression.

---

## What Is a Melody?

A **melody** is a linear sequence of notes perceived as a single musical idea.

A good melody usually has:

- A clear shape
- A sense of direction
- Repetition and variation
- Tension and release

For example:

```
C  D  E  G  E  D  C
```

Even though it is just a sequence of notes, your brain groups it into a coherent idea.

---

## Motifs

A **motif** is the smallest recognizable musical idea.

It is usually:

- Short (2–5 notes)
- Repeated or varied
- Used as a building block

Example motif:

```
C  D  E
```

This motif can be repeated, transposed, or rhythmically altered.

Many famous pieces are built from simple motifs developed over time.

---

## Phrases

A **phrase** is a complete musical thought, similar to a sentence in language.

Typically:

- A phrase lasts 4–8 measures (but not always)
- It ends with a sense of pause or resolution

Example:

```
Phrase 1: C D E F | G A B C
Phrase 2: C B A G | F E D C
```

Music often uses **question and answer** phrasing:

- First phrase = question (unfinished feeling)
- Second phrase = answer (resolution)

---

## Sequences

A **sequence** is when a motif is repeated at different pitch levels.

Example:

```
C  D  E
D  E  F♯
E  F♯ G♯
```

Sequences create forward motion and development in melodies.

They are commonly used in classical music, jazz improvisation, and film scoring.

---

## Melodic Contour

**Melodic contour** describes the overall shape of a melody.

Common contours include:

- Ascending (rising)
- Descending (falling)
- Arch shape (rise then fall)
- Wave-like (multiple rises and falls)

Example:

```
Ascending:
C → D → E → F

Descending:
F → E → D → C

Arch:
C → D → E → D → C
```

A good melody usually avoids being completely flat or random—it has direction and shape.

---

## Steps and Leaps

Melodies are built from two types of motion:

### Stepwise Motion

Moving between adjacent notes:

```
C → D → E → F
```

- Smooth
- Easy to sing
- Common in melodies

---

### Leaps (Skips)

Moving between non-adjacent notes:

```
C → G
E → B
A → F
```

- Adds interest
- Creates emotional impact
- Must be balanced with stepwise motion

---

## Consonance and Dissonance

Melodies often interact with harmony using consonant and dissonant intervals.

- **Consonance** = stable, pleasant
- **Dissonance** = tense, unresolved

Example:

- C over C major chord = consonant
- D over C major chord = slightly dissonant (adds color)

Good melodies balance both:

- Consonance for stability
- Dissonance for tension and movement

---

## Tension and Release in Melody

Melodies often follow a pattern of:

```
Tension → Release
```

Tension can come from:

- Large leaps
- Dissonant notes
- Higher register notes
- Non-chord tones

Release happens when:

- The melody resolves to chord tones
- It returns to stable notes like the tonic

Example in C major:

```
Melody:  E → F → G → E → C
Harmony: C major chord underneath
```

The motion toward C feels like resolution.

---

## Chord Tones vs Non-Chord Tones

Melodies often use two types of notes:

### Chord Tones

Notes that belong to the underlying chord.

Example in C major chord (C–E–G):

- C
- E
- G

These sound stable.

---

### Non-Chord Tones

Notes that are not in the chord but add movement.

Examples:

- Passing tones
- Neighbor tones
- Suspensions

Example:

```
Chord: C major (C–E–G)
Melody: C → D → E
```

D is a **passing tone**.

Non-chord tones create melodic interest and direction.

---

## Repetition and Variation

Good melodies balance:

- **Repetition** (familiarity)
- **Variation** (interest)

Example:

```
C D E | C D E | C E D | C D E
```

Too much repetition becomes boring. Too much variation becomes confusing.

---

## Call and Response

Many melodies use a **call and response** structure.

- Call: A musical idea (question)
- Response: A contrasting idea (answer)

Example:

```
Call:     C D E F
Response: G F E C
```

This structure is common in:

- Blues
- Jazz
- Gospel
- African and folk traditions

---

## Writing a Simple Melody

A simple method for writing melodies:

1. Choose a scale (e.g., C major)
2. Start and end on the tonic
3. Use mostly stepwise motion
4. Add occasional leaps for interest
5. Repeat and vary a motif
6. Match important notes with chord tones

Example:

```
C  D  E  G  E  D  C
```

This melody:
- Starts and ends on C
- Uses mostly steps
- Includes one leap (E → G)
- Feels complete and balanced

---

## Melody and Harmony Relationship

Melody and harmony are deeply connected.

A melody usually:

- Fits within a key
- Emphasizes chord tones on strong beats
- Uses non-chord tones on weak beats

Example:

```
Chord: C major
Melody: E → D → C → G
```

The melody sounds coherent because it aligns with harmonic structure.

---

## Practice Examples

### Example 1

What is a motif?

**Answer:**
A short musical idea that serves as a building block for melodies.

---

### Example 2

What is melodic contour?

**Answer:**
The overall shape or direction of a melody.

---

### Example 3

What is the difference between stepwise motion and a leap?

**Answer:**
- Stepwise motion moves between adjacent notes.
- A leap skips one or more notes.

---

### Example 4

What is a phrase in music?

**Answer:**
A complete musical thought, similar to a sentence.

---

### Example 5

What is a passing tone?

**Answer:**
A non-chord tone that connects two chord tones by stepwise motion.

---

## Key Takeaways

- Melody is a sequence of single notes forming a musical idea.
- Motifs are small building blocks of melodies.
- Phrases are complete musical thoughts.
- Sequences repeat ideas at different pitch levels.
- Melodic contour describes the shape of a melody.
- Stepwise motion is smooth; leaps add contrast.
- Tension and release give melodies emotional direction.
- Melodies interact with harmony using chord tones and non-chord tones.
- Good melodies balance repetition and variation.

---

## Summary

Melody is the most recognizable part of music and often what listeners remember first. In this chapter, you learned how melodies are built from motifs, phrases, and sequences, how melodic contour shapes musical ideas, and how stepwise motion and leaps create movement. You also explored how melody interacts with harmony through chord tones, non-chord tones, and tension and release.

In the next chapter, you will learn about **keys and modulation**, which explain how music can shift between tonal centers while maintaining coherence.